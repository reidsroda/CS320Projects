import json
import csv
import zipfile as z
import io

race_lookup = {
        "1": "American Indian or Alaska Native",
        "2": "Asian",
        "21": "Asian Indian",
        "22": "Chinese",
        "23": "Filipino",
        "24": "Japanese",
        "25": "Korean",
        "26": "Vietnamese",
        "27": "Other Asian",
        "3": "Black or African American",
        "4": "Native Hawaiian or Other Pacific Islander",
        "41": "Native Hawaiian",
        "42": "Guamanian or Chamorro",
        "43": "Samoan",
        "44": "Other Pacific Islander",
        "5": "White",
}

class Applicant:
    def __init__(self, age, race):
        self.age = age
        self.race = set() 
        for r in race:
            try:
                self.race.add(race_lookup[r])
            except:
                pass
            
            
    def __repr__(self):
        return f"{self.__class__.__name__}('{self.age}', {list(self.race)})"
            
    
    def lower_age(self):
        agerep = int(self.age.replace('>','').replace('<','').split('-')[0])
        return agerep
        
    def __lt__(self, other):
        return int(self.lower_age()) < int(other.lower_age())
        
class Loan:
    def __init__(self, values):
        try:
            self.loan_amount = float(values["loan_amount"])
        except ValueError:
            self.loan_amount = -1
        try:
            self.property_value = float(values['property_value'])
        except ValueError:
            self.property_value = -1
        try:
            self.interest_rate = float(values['interest_rate'])
        except ValueError:
            self.interest_rate = -1
        applicant_races = []
        for n in range(1, 6):
            string = 'applicant_race-' + str(n)
            try:
                if values[string] != '':
                    applicant_races.append(values[string])
            except:
                 pass  
        applicant_list = []
        applicant_list.append(Applicant(values['applicant_age'], applicant_races))
                                       
        if values["co-applicant_age"] != "9999":
            coapp_races = []
            for i in range(1,6):
                string = "co-applicant_race-" + str(i)
                try:
                    if values[string] != '':
                        coapp_races.append(values[string])
                except:
                     pass
            applicant_list.append(Applicant(values['co-applicant_age'], coapp_races))
        self.applicants = applicant_list
    def __str__(self):
        return f"<Loan: {self.interest_rate}% on ${self.property_value} with {len(self.applicants)} applicant(s)>"
    def __repr__(self):
        return f"<Loan: {self.interest_rate}% on ${self.property_value} with {len(self.applicants)} applicant(s)>"                             

    def yearly_amounts(self, yearly_payment):
        assert self.interest_rate > 0

        assert yearly_payment > 0

        amt = self.loan_amount
       
        while amt > 0:
            yield(amt)
            amt = amt + (amt * (self.interest_rate / 100))
            amt -= yearly_payment

class Bank:
    def __init__(self, name):
        self.loans = []
        self.name = name

        with open("banks.json") as f:
            data = f.read()
        for i in json.loads(data):
            if i['name'] == name:
                self.name = name
                self.lei = i['lei']
        with z.ZipFile('wi.zip') as zf:
            with zf.open('wi.csv','r') as file:
                reader = csv.DictReader(io.TextIOWrapper(file,'utf-8'))
                for row in reader:
                    if self.lei == row['lei']:
                        l = Loan(row)
                        self.loans.append(l)
            
    def __getitem__(self, search):
        return self.loans[search]
        
        
    def __len__(self):
        return len(self.loans)
    

                            